import BaseNavigator from "./BaseNavigator";
export default BaseNavigator