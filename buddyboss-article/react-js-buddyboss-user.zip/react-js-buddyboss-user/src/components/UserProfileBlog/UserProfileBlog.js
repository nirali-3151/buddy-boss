import React, { Component } from 'react'

class UserProfileBlog extends Component {
  render() {
    return (
      <div>UserProfileBlog</div>
    )
  }
}


export default UserProfileBlog