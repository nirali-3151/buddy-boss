import React, { Component } from 'react'

class DeleteBlog extends Component {
  render() {
    return (
      <div>DeleteBlog</div>
    )
  }
}

export default DeleteBlog
